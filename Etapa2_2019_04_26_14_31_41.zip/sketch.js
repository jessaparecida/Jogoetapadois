/* 
    Equipe: 
        Jéssica Aparecida Silva Costa - Subturma D (Líder) 
        Patrick William de Carvalho Segundo- Subturma A
        Etapa 2
*/

var x =  200 ;
var y =  350 ;
function setup() {
  createCanvas(400, 400);
  frameRate ( 30 );
}

function draw() {
  background(150);
  if ( keyIsDown ( RIGHT_ARROW )){x = x +  5 ;}
  ellipse(x, y, 55, 55);
  rect ( 170 , 50 , 55 , 55 );
}